from selenium import webdriver
import time
import bs4


driver=webdriver.Chrome('./chromedriver')

driver.get('url="https://www.google.com/maps/place/Monal+Restaurant/@31.5066104,74.3243772,12z/data=!4m8!1m2!2m1!1sRestaurants!3m4!1s0x3919045c800b7a65:0x9bfe5a537cfceea4!8m2!3d31.5097989!4d74.3410679"')


phone_number = []

num = driver.find_elements_by_class_name("ugiz4pqJLAG__text")
print([i.text for i in num])
for i in num:
    s = i.text
    if (s[:3] == "+92" or s[:2] == "03" or s[0]=="+"):
        phone_number.append(s)


print(phone_number)
